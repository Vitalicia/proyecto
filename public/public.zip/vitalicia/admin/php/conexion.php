<?php

$conexion = mysqli_connect("mysql.hostinger.mx","u435473506_netit","patito01","u435473506_netit") or die ("Lo sentimos ha ocurrido un error");
?>